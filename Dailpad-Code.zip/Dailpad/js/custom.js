jQuery(document).ready(function(){

    // Add Dial Num

    jQuery('.dail_num').on('click', function(){
        var getval = $(this).find('span').text();
        jQuery('.dail_code').append('<span class="count">' + getval + '</span>');
        //console.log(getval)
    });

    // Remove Dial Num

    jQuery('.back').on('click', function() {
        jQuery(this).parents('.dailpad_innercontent').find('.dail_code .count:last-child').remove();
    });

    // Add to Fav.

    jQuery('.star_fav').on('click', function() {
        jQuery(this).find('i').toggleClass('fas fa-star');
        jQuery(this).find('i').toggleClass('far fa-star');
    });

    // Call Btn.

    jQuery('.call').on('click', function() {
        var getlength = jQuery('.dail_code .count').length;
        if(getlength < 1){
            alert('Please enter a valid number');
        }else{
            alert('Dailing...')
        }
    });

});